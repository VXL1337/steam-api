export default async function handler(req, res) {

  try {

    const id = req.query.id;

    const response = await fetch(
      `https://store.steampowered.com/api/appdetails?appids=${id}`
    );

    const data = await response.json();

    const game = data[id]?.data;

    res.setHeader(
      "Cache-Control",
      "s-maxage=86400"
    );

    res.status(200).json({
      title: game.name,
      description: game.short_description,
      banner: game.header_image,
      screenshots: game.screenshots?.map(
        s => s.path_full
      )
    });

  } catch (err) {

    res.status(500).json({
      error: err.message
    });

  }

}